#include "coord_decrypt.h"
开源频道:@enennba
#include "coord_driver_bridge.h"
#include "Assistinclude/Dec/ExecuteDec.h"
#include "Assistinclude/Dec/FindDec.h"

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <mutex>
#include <new>
#include <sstream>
#include <string>
#include <sys/stat.h>
#include <unordered_map>
#include <vector>

namespace
{
constexpr uint64_t kDecryptJumpout = 0x0E738950;
constexpr uint64_t kDecryptKeyOffset = 0x210;
constexpr uint64_t kEntryStride = 48;
constexpr uint64_t kPoolHeadSkip = 16;
constexpr uint64_t kRefreshFrames = 60;
constexpr uint64_t kMaxShellcodeDumpSize = 128ULL * 1024ULL * 1024ULL;
constexpr size_t kDumpPageSize = 4096;

using CoordDecrypt::Coordinate;

struct DecryptContext
{
	uint64_t libUE4 = 0;
	uint64_t decryptCtx = 0;
	uint64_t decryptV87 = 0;
	uint64_t tls = 0;
	uint64_t lastPoolPtr = 0;
	uint64_t frame = 0;
	bool enabled = false;
	bool unicornReady = false;
	bool paramsReady = false;
};

struct DecryptSlot
{
	uint64_t ring = 0;
	uint64_t stamp = 0;
};

DecryptContext g_context;
coord_dec::FindDec g_findDec;
std::unordered_map<uint64_t, DecryptSlot> g_slots;
std::mutex g_mutex;

uint64_t Untag(uint64_t value)
{
	return value & 0x00FFFFFFFFFFFFFFULL;
}

bool IsPointer(uint64_t value)
{
	return value > 0x10000000ULL && value < 0x10000000000ULL && value != 0x7F800001ULL;
}

bool IsFiniteCoordinate(const Coordinate &value)
{
	return std::isfinite(value.x) &&
		   std::isfinite(value.y) &&
		   std::isfinite(value.z);
}

bool ReadMemory(uint64_t address, void *buffer, size_t size)
{
	return CoordDriverBridge::Read(Untag(address), buffer, size);
}

void CloseDecryptLocked()
{
	if (g_context.unicornReady)
		coord_dec::close_unicorn();
	g_context = {};
	g_findDec.~FindDec();
	new (&g_findDec) coord_dec::FindDec();
	g_slots.clear();
}

bool ParseContext(uint64_t libUE4, uint64_t &context, uint64_t &entry)
{
	uint64_t bridge = 0;
	if (!ReadMemory(libUE4 + kDecryptJumpout + 12, &bridge, sizeof(bridge)))
		return false;

	const uint64_t shellcode = Untag(bridge);
	uint64_t rawContext = 0;
	uint64_t rawEntry = 0;
	if (!IsPointer(shellcode) ||
		!ReadMemory(shellcode - 8, &rawContext, sizeof(rawContext)) ||
		!ReadMemory(shellcode + 0xA0, &rawEntry, sizeof(rawEntry)))
		return false;

	context = rawContext;
	entry = Untag(rawEntry);
	return IsPointer(Untag(context)) && IsPointer(entry);
}

bool LoadShellcode(uint64_t entry, uint64_t &base, std::vector<uint8_t> &data)
{
	auto regions = CoordDriverBridge::GetScanRegions();
	for (const auto &region : regions)
	{
		if (entry >= region.first && entry < region.second)
		{
			base = region.first;
			const uint64_t size = region.second - region.first;
			if (size == 0 || size > 0x200000)
				return false;
			data.assign(static_cast<size_t>(size), 0);
			bool entryPageRead = false;
			for (uint64_t offset = 0; offset < size; offset += 4096)
			{
				const size_t chunk = static_cast<size_t>(std::min<uint64_t>(4096, size - offset));
				const bool ok = ReadMemory(base + offset, data.data() + offset, chunk);
				if (entry >= base + offset && entry < base + offset + chunk)
					entryPageRead = ok;
			}
			return entryPageRead;
		}
	}
	return false;
}

struct DumpPageStatus
{
	uint64_t address = 0;
	size_t size = 0;
	bool read = false;
};

bool EnsureDirectory(const std::string &path, std::string &error)
{
	if (::mkdir(path.c_str(), 0777) == 0 || errno == EEXIST)
		return true;
	error = std::string("创建目录失败: ") + path + " (" + std::strerror(errno) + ")";
	return false;
}

std::string MakeDumpTimestamp()
{
	const auto now = std::chrono::system_clock::now();
	const auto milliseconds =
		std::chrono::duration_cast<std::chrono::milliseconds>(
			now.time_since_epoch()) %
		1000;
	const std::time_t currentTime =
		std::chrono::system_clock::to_time_t(now);
	std::tm localTime{};
	localtime_r(&currentTime, &localTime);
	char dateTime[32]{};
	std::strftime(
		dateTime,
		sizeof(dateTime),
		"%Y-%m-%d_%H-%M-%S",
		&localTime);
	char timestamp[48]{};
	std::snprintf(
		timestamp,
		sizeof(timestamp),
		"%s_%03lld",
		dateTime,
		static_cast<long long>(milliseconds.count()));
	return timestamp;
}

uint64_t Fnv1a64(const std::vector<uint8_t> &data)
{
	uint64_t hash = 14695981039346656037ULL;
	for (const uint8_t value : data)
	{
		hash ^= value;
		hash *= 1099511628211ULL;
	}
	return hash;
}

void WriteHexDump(
	std::ofstream &file,
	uint64_t base,
	const std::vector<uint8_t> &data)
{
	static constexpr char kHex[] = "0123456789ABCDEF";
	char line[128]{};
	for (size_t offset = 0; offset < data.size(); offset += 16)
	{
		char *cursor = line;
		const int prefixLength = std::snprintf(
			line,
			sizeof(line),
			"%016llX  ",
			static_cast<unsigned long long>(base + offset));
		if (prefixLength <= 0)
			return;
		cursor += prefixLength;

		for (size_t column = 0; column < 16; ++column)
		{
			if (offset + column < data.size())
			{
				const uint8_t value = data[offset + column];
				*cursor++ = kHex[value >> 4];
				*cursor++ = kHex[value & 0x0F];
			}
			else
			{
				*cursor++ = ' ';
				*cursor++ = ' ';
			}
			*cursor++ = ' ';
			if (column == 7)
				*cursor++ = ' ';
		}

		*cursor++ = ' ';
		*cursor++ = '|';
		for (size_t column = 0; column < 16; ++column)
		{
			if (offset + column >= data.size())
			{
				*cursor++ = ' ';
				continue;
			}
			const uint8_t value = data[offset + column];
			*cursor++ =
				value >= 0x20 && value <= 0x7E
					? static_cast<char>(value)
					: '.';
		}
		*cursor++ = '|';
		*cursor++ = '\n';
		file.write(line, static_cast<std::streamsize>(cursor - line));
	}
}

bool ResolveMemoryParam(coord_dec::param &param)
{
	if (param.size == 0 || param.size > sizeof(param.value))
		return false;
	if (param.offset.empty())
		return true;

	uint64_t pointer = Untag(param.value);
	if (!IsPointer(pointer))
		return false;

	for (size_t i = 0; i < param.offset.size(); ++i)
	{
		const uint64_t address = pointer + static_cast<int64_t>(param.offset[i]);
		if (i + 1 == param.offset.size())
		{
			uint64_t value = 0;
			if (!ReadMemory(address, &value, param.size))
				return false;
			param.value = value;
			return true;
		}

		uint64_t next = 0;
		if (!ReadMemory(address, &next, sizeof(next)))
			return false;
		pointer = Untag(next);
		if (!IsPointer(pointer))
			return false;
	}
	return false;
}

bool PrepareParameters(uint64_t component)
{
	CoordDriverBridge::Environment environment{};
	if (!CoordDriverBridge::GetGameThreadEnvironment(environment))
		return false;

	if (coord_dec::execute_all_params(g_context.decryptCtx,
										component + kDecryptKeyOffset,
										environment.tls,
										g_findDec.analyze.varParams,
										g_findDec.mem_param_list,
										environment.pacgaLo,
										environment.pacgaHi) != 0)
		return false;

	for (auto &param : g_findDec.mem_param_list)
	{
		if (!ResolveMemoryParam(param))
			return false;
	}

	g_findDec.setup_param();
	g_context.tls = environment.tls;
	g_context.paramsReady = true;
	return true;
}

bool EnsureInitialized(uint64_t component)
{
	if (g_context.unicornReady && g_context.paramsReady)
		return true;
	if (!IsPointer(g_context.libUE4) || !IsPointer(component))
		return false;

	uint64_t entry = 0;
	if (!ParseContext(g_context.libUE4, g_context.decryptCtx, entry))
		return false;

	uint64_t shellcodeBase = 0;
	std::vector<uint8_t> shellcode;
	if (!LoadShellcode(entry, shellcodeBase, shellcode) ||
		g_findDec.set(shellcodeBase, shellcode.data(), static_cast<uint32_t>(shellcode.size())) != 0 ||
		g_findDec.find_dec(entry) != 0 ||
		coord_dec::init_unicorn(g_findDec) != 0)
	{
		CloseDecryptLocked();
		return false;
	}

	g_context.unicornReady = true;
	g_context.decryptV87 = coord_dec::execute_v87_compute(g_context.decryptCtx);
	if (g_context.decryptV87 == 0 || !PrepareParameters(component))
	{
		CloseDecryptLocked();
		return false;
	}
	return true;
}

void RefreshPoolPointer()
{
	if (!g_context.paramsReady || g_context.decryptV87 == 0 || g_findDec.pool_ptr_offset == 0)
		return;

	uint64_t poolPointer = 0;
	if (!ReadMemory(g_context.decryptV87 + g_findDec.pool_ptr_offset, &poolPointer, sizeof(poolPointer)) || poolPointer == 0)
		return;
	if (g_context.lastPoolPtr != 0 && g_context.lastPoolPtr != poolPointer)
		g_slots.clear();
	g_context.lastPoolPtr = poolPointer;
}
} // namespace

extern "C" int qh_dec_read_mem(uint64_t address, void *buffer, unsigned long size)
{
	return ReadMemory(address, buffer, static_cast<size_t>(size)) ? 0 : -1;
}

namespace CoordDecrypt
{
void Tick(bool enabled, uint64_t libUE4)
{
	std::lock_guard<std::mutex> lock(g_mutex);
	if (!enabled)
	{
		if (g_context.enabled || g_context.unicornReady)
			CloseDecryptLocked();
		return;
	}

	if (g_context.libUE4 != 0 && g_context.libUE4 != libUE4)
		CloseDecryptLocked();
	g_context.enabled = true;
	g_context.libUE4 = libUE4;
	++g_context.frame;
}

bool TryRead(uint64_t component, Coordinate &out)
{
	std::lock_guard<std::mutex> lock(g_mutex);
	if (!g_context.enabled || !IsPointer(component) || !EnsureInitialized(component))
		return false;

	RefreshPoolPointer();
	DecryptSlot *slot = nullptr;
	auto it = g_slots.find(component);
	const bool stale = it != g_slots.end() && g_context.frame - it->second.stamp >= kRefreshFrames;
	if (it == g_slots.end() || it->second.ring == 0 || stale)
	{
		uint64_t ring = 0;
		if (coord_dec::execute_hash_binary_search(g_context.decryptCtx,
											component + kDecryptKeyOffset,
											static_cast<uint32_t>(g_context.frame),
											ring,
											g_context.tls) == 0 && IsPointer(Untag(ring)))
		{
			DecryptSlot &newSlot = g_slots[component];
			newSlot.ring = Untag(ring);
			newSlot.stamp = g_context.frame;
			slot = &newSlot;
		}
		else if (it != g_slots.end() && it->second.ring != 0)
		{
			slot = &it->second;
		}
		else
		{
			return false;
		}
	}
	else
	{
		slot = &it->second;
	}

	const uint64_t indexAddress = slot->ring + g_findDec.index_offset;
	uint64_t index = 0;
	uint64_t indexAfter = 0;
	Coordinate decoded{};
	bool stable = false;
	for (int attempt = 0; attempt < 2; ++attempt)
	{
		if (!ReadMemory(indexAddress, &index, sizeof(index)))
			break;
		const uint64_t poolSlot = g_findDec.decode_ring_slot(index);
		const uint64_t coordinateAddress = slot->ring + g_findDec.get_ring_offset() +
										   kPoolHeadSkip + kEntryStride * poolSlot;
		if (!ReadMemory(coordinateAddress, &decoded, sizeof(decoded)) ||
			!ReadMemory(indexAddress, &indexAfter, sizeof(indexAfter)))
			break;
		if (index == indexAfter)
		{
			stable = true;
			break;
		}
	}

	if (!stable || !IsFiniteCoordinate(decoded))
		return false;

	out = decoded;
	return true;
}

ShellcodeDumpResult DumpShellcode(uint64_t libUE4)
{
	ShellcodeDumpResult result{};
	if (!IsPointer(libUE4))
	{
		result.message = "DumpShellcode失败: libUE4未就绪，请先开启辅助";
		return result;
	}

	const uint64_t bridgeAddress =
		libUE4 + kDecryptJumpout + 12;
	uint64_t rawBridge = 0;
	if (!ReadMemory(bridgeAddress, &rawBridge, sizeof(rawBridge)))
	{
		result.message = "DumpShellcode失败: 无法读取跳板字段";
		return result;
	}

	const uint64_t shellcodeBridge = Untag(rawBridge);
	uint64_t rawContext = 0;
	uint64_t rawEntry = 0;
	if (!IsPointer(shellcodeBridge) ||
		!ReadMemory(shellcodeBridge - 8, &rawContext, sizeof(rawContext)) ||
		!ReadMemory(shellcodeBridge + 0xA0, &rawEntry, sizeof(rawEntry)))
	{
		result.message = "DumpShellcode失败: 跳板无效或上下文/入口读取失败";
		return result;
	}

	const uint64_t entry = Untag(rawEntry);
	if (!IsPointer(entry))
	{
		result.message = "DumpShellcode失败: 解密入口指针无效";
		return result;
	}

	const auto regions = CoordDriverBridge::GetScanRegions();
	uint64_t regionBase = 0;
	uint64_t regionEnd = 0;
	for (const auto &region : regions)
	{
		if (entry >= region.first && entry < region.second)
		{
			regionBase = region.first;
			regionEnd = region.second;
			break;
		}
	}
	if (regionBase == 0 || regionEnd <= regionBase)
	{
		result.message = "DumpShellcode失败: 扫描区中找不到入口所属内存区";
		return result;
	}

	const uint64_t regionSize = regionEnd - regionBase;
	if (regionSize > kMaxShellcodeDumpSize)
	{
		char message[160]{};
		std::snprintf(
			message,
			sizeof(message),
			"DumpShellcode失败: 内存区过大 0x%llX，安全上限128MiB",
			static_cast<unsigned long long>(regionSize));
		result.message = message;
		return result;
	}

	std::vector<uint8_t> shellcode(
		static_cast<size_t>(regionSize),
		0);
	std::vector<DumpPageStatus> pages;
	pages.reserve(
		static_cast<size_t>(
			(regionSize + kDumpPageSize - 1) /
			kDumpPageSize));
	for (uint64_t offset = 0; offset < regionSize; offset += kDumpPageSize)
	{
		const size_t pageSize =
			static_cast<size_t>(
				std::min<uint64_t>(
					kDumpPageSize,
					regionSize - offset));
		const bool pageRead = ReadMemory(
			regionBase + offset,
			shellcode.data() + offset,
			pageSize);
		pages.push_back({regionBase + offset, pageSize, pageRead});
		if (pageRead)
			++result.pagesRead;
		else
			++result.pagesFailed;
	}

	std::string error;
	const std::string rootDirectory = "/sdcard/shellcode";
	if (!EnsureDirectory(rootDirectory, error))
	{
		result.message = "DumpShellcode失败: " + error;
		return result;
	}
	result.directory = rootDirectory + "/" + MakeDumpTimestamp();
	if (!EnsureDirectory(result.directory, error))
	{
		result.message = "DumpShellcode失败: " + error;
		return result;
	}

	result.binaryPath = result.directory + "/shellcode.bin";
	result.textPath = result.directory + "/shellcode.txt";
	std::ofstream binaryFile(
		result.binaryPath,
		std::ios::binary | std::ios::trunc);
	if (!binaryFile.is_open())
	{
		result.message = "DumpShellcode失败: 无法创建shellcode.bin";
		return result;
	}
	binaryFile.write(
		reinterpret_cast<const char *>(shellcode.data()),
		static_cast<std::streamsize>(shellcode.size()));
	binaryFile.close();
	if (!binaryFile)
	{
		result.message = "DumpShellcode失败: shellcode.bin写入不完整";
		return result;
	}

	std::ofstream textFile(result.textPath, std::ios::trunc);
	if (!textFile.is_open())
	{
		result.message = "DumpShellcode失败: 无法创建shellcode.txt";
		return result;
	}

	textFile << "================ Shellcode Dump Report ================\n";
	textFile << "Directory            : " << result.directory << '\n';
	textFile << "Binary file          : " << result.binaryPath << '\n';
	textFile << "libUE4               : 0x" << std::hex << std::uppercase << libUE4 << '\n';
	textFile << "Jump offset          : 0x" << kDecryptJumpout << '\n';
	textFile << "Bridge field         : 0x" << bridgeAddress << '\n';
	textFile << "Bridge raw           : 0x" << rawBridge << '\n';
	textFile << "Bridge untagged      : 0x" << shellcodeBridge << '\n';
	textFile << "Context field        : 0x" << shellcodeBridge - 8 << '\n';
	textFile << "Context raw          : 0x" << rawContext << '\n';
	textFile << "Context untagged     : 0x" << Untag(rawContext) << '\n';
	textFile << "Entry field          : 0x" << shellcodeBridge + 0xA0 << '\n';
	textFile << "Entry raw            : 0x" << rawEntry << '\n';
	textFile << "Entry untagged       : 0x" << entry << '\n';
	textFile << "Region base          : 0x" << regionBase << '\n';
	textFile << "Region end           : 0x" << regionEnd << '\n';
	textFile << "Region size          : 0x" << regionSize << " (" << std::dec << regionSize << " bytes)\n";
	textFile << "Entry region offset  : 0x" << std::hex << entry - regionBase << '\n';
	textFile << "FNV-1a 64            : 0x" << Fnv1a64(shellcode) << '\n';
	textFile << "Pages read           : " << std::dec << result.pagesRead << '\n';
	textFile << "Pages failed         : " << result.pagesFailed << '\n';
	textFile << "Failed page fill     : 00\n";

	textFile << "\n================ All Scan Regions ================\n";
	for (size_t index = 0; index < regions.size(); ++index)
	{
		const auto &region = regions[index];
		textFile << '[' << std::dec << index << "] 0x"
				 << std::hex << region.first << " - 0x" << region.second
				 << " size=0x" << region.second - region.first;
		if (entry >= region.first && entry < region.second)
			textFile << "  <ENTRY>";
		textFile << '\n';
	}

	textFile << "\n================ Page Read Map ================\n";
	for (size_t index = 0; index < pages.size(); ++index)
	{
		const DumpPageStatus &page = pages[index];
		textFile << '[' << std::dec << index << "] 0x"
				 << std::hex << page.address
				 << " size=0x" << page.size
				 << " status=" << (page.read ? "OK" : "FAILED_ZERO_FILLED")
				 << '\n';
	}

	textFile << "\n================ Full Hex + ASCII Dump ================\n";
	WriteHexDump(textFile, regionBase, shellcode);
	textFile.close();
	if (!textFile)
	{
		result.message = "DumpShellcode失败: shellcode.txt写入不完整";
		return result;
	}

	result.saved = true;
	result.complete = result.pagesFailed == 0;
	result.base = regionBase;
	result.entry = entry;
	result.size = shellcode.size();
	std::ostringstream message;
	message << "DumpShellcode保存成功: " << result.directory
			<< "，0x" << std::hex << std::uppercase << result.size
			<< "字节";
	if (!result.complete)
		message << "，失败页" << std::dec << result.pagesFailed << "个(已填0)";
	result.message = message.str();
	std::printf(
		"[ShellcodeDump] %s\n",
		result.message.c_str());
	return result;
}

void Reset()
{
	std::lock_guard<std::mutex> lock(g_mutex);
	CloseDecryptLocked();
}
} // namespace CoordDecrypt
开源频道:@enennba