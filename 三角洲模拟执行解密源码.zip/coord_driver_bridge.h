#pragma once
开源频道:@enennba
#include <cstddef>
#include <cstdint>
#include <utility>
#include <vector>

namespace CoordDriverBridge
{
struct Environment
{
	uint64_t tls = 0;
	uint64_t pacgaLo = 0;
	uint64_t pacgaHi = 0;
};

bool Read(uint64_t address, void *buffer, size_t size);
std::vector<std::pair<uintptr_t, uintptr_t>> GetScanRegions();
bool GetGameThreadEnvironment(Environment &environment);
}
开源频道:@enennba