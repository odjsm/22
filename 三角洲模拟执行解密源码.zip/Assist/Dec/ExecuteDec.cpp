#include "unicorn/unicorn.h"
#include <iostream>
#include <vector>
#include <cstring>
#include <asm-generic/unistd.h>
#include <fcntl.h>
#include "src/driver_api.h"
#include "FindDec.h"
#include "pauth_helper.h"
namespace coord_dec {
    static uc_arm64_reg convert_reg(arm64_reg reg) {
        return (uc_arm64_reg) (reg - (ARM64_REG_X0 - (int)UC_ARM64_REG_X0));
    }


    static int read_original_memory(uint64_t addr, uint8_t *buf, size_t size) {
        return KernelDriver::SCHE_readProcessMemory(addr, buf, size);
    }

    static uc_engine *uc;
    static std::vector<uint64_t> mmap;
    static uint32_t last_count = 0;

    bool any = false;

    static bool hook_mem_invalid(uc_engine *uc, uc_mem_type type,
                                 uint64_t address, int size, int64_t value, void *user_data) {
        (void) size;
        (void) value;
        (void) user_data;

        if (type == UC_MEM_READ_UNMAPPED ||
            type == UC_MEM_WRITE_UNMAPPED ||
            type == UC_MEM_FETCH_UNMAPPED) {
            uint64_t page_start = address & ~0xFFF;

            // 鍒嗛厤涓€椤?
            uc_err err = uc_mem_map(uc, page_start, 0x1000, UC_PROT_ALL);
            if (err) {
                printf("Failed on uc_mem_map with error returned: %u (%s)\n", err,
                       uc_strerror(err));
                return false;
            }

            uint8_t buf[0x1000];
            memset(buf, 0, sizeof(buf));
//            printf("mem_invalid! at %lx in page %lx\n ", address, page_start);

            // 浠庡師濮嬬▼搴忚鍙栨暟鎹～鍏?
            int ret = read_original_memory(page_start, buf, 0x1000);
            uint64_t pc;
            uc_reg_read(uc, UC_ARM64_REG_PC, &pc);
        
            uint64_t sp, x0;
            uc_reg_read(uc, UC_ARM64_REG_SP, &sp);
            uc_reg_read(uc, UC_ARM64_REG_X0, &x0);
     
            if (!ret) {
                err = uc_mem_write(uc, page_start, buf, 0x1000);
                if (err) {
                    uc_mem_unmap(uc, page_start, 0x1000);
                    printf("Failed on uc_mem_write with error returned: %u (%s)\n", err,
                           uc_strerror(err));
                    return false;
                }
                mmap.push_back(page_start);
                return true;
            }

            if (any) {
                mmap.push_back(page_start);
                return true;
            }

            uc_mem_unmap(uc, page_start, 0x1000);
            return false;
        }
        return false;
    }

    static constexpr uint64_t sp_base = 0x7ffff000;
    static constexpr uint64_t stack_base = 0x7ff00000;
    static constexpr uint64_t stack_size = 0x10000;

    static uint64_t v87_compute_start;
    static uint64_t v87_compute_end;
    static uc_arm64_reg v87_compute_reg;

    static uint64_t hash_binary_search_start;
    static uint64_t hash_binary_search_end;
    static uc_arm64_reg hash_binary_search_reg;

    static uint64_t all_params_exec_end;

    static uint64_t shellcode_end;

    static bool init_shellcode_offset(FindDec &findDec) {

        shellcode &code = *findDec.get_shellcode();

        method *entry = code.get_method("entry");
        if (!entry) return false;

        point *v87_exec_end = entry->get_point("v87_end");
        if (!v87_exec_end) return false;

        v87_compute_start = entry->start_address();
        v87_compute_end = v87_exec_end->address;
        v87_compute_reg = convert_reg(v87_exec_end->reg);

        point *hash_exec_end = entry->get_point("hash_end");
        if (!hash_exec_end) return false;

        hash_binary_search_start = entry->start_address();
        hash_binary_search_end = hash_exec_end->address;
        hash_binary_search_reg = convert_reg(hash_exec_end->reg);

        point *exec_end = entry->get_point("all_params_exec_end");
        if (!exec_end)
            std::cout << "[warning] unicorn param all_params_exec_end not init" << std::endl;
        else {
            all_params_exec_end = exec_end->address;
        }

        shellcode_end = entry->end_address();
        return true;
    }

    static inline uint64_t read_ctr_el0(void) {
        uint64_t val;
        asm volatile("mrs %0, ctr_el0" : "=r"(val));
        return val;
    }

    static inline uint64_t read_cntfrq_el0(void) {
        uint64_t val;
        asm volatile("mrs %0, cntfrq_el0" : "=r"(val));
        return val;
    }

    static inline uint64_t read_cntvct() {
        uint64_t val;
        __asm__ volatile("mrs %0, cntvct_el0" : "=r"(val));
        return val;
    }

    // Handle MRS reads of system registers generically (CTR_EL0, CNTFRQ_EL0,
    // CNTVCT_EL0, CNTVCTSS_EL0). No static addresses required -> works on the
    // flattened build that scatters dozens of these timer reads as junk.
    static uint32_t hook_mrs(uc_engine *uc, uc_arm64_reg reg,
                             const uc_arm64_cp_reg *cp_reg, void *user_data) {
        if (!cp_reg) {
            return 0;
        }
        // op0==3, op1==3 covers the EL0-readable system registers used here.
        if (cp_reg->op0 == 3 && cp_reg->op1 == 3) {
            uint64_t v = 0;
            if (cp_reg->crn == 0 && cp_reg->crm == 0 && cp_reg->op2 == 1) {
                v = read_ctr_el0();                         // CTR_EL0
            } else if (cp_reg->crn == 14 && cp_reg->crm == 0 && cp_reg->op2 == 0) {
                v = read_cntfrq_el0();                       // CNTFRQ_EL0
            } else if (cp_reg->crn == 14 && cp_reg->crm == 0 && cp_reg->op2 == 2) {
                v = read_cntvct();                       // CNTVCT_EL0
            } else if (cp_reg->crn == 14 && cp_reg->crm == 0 && cp_reg->op2 == 6) {
                v = read_cntvct();                       // CNTVCTSS_EL0
            } else {
                return 0; // let unknown sysregs fall through to default behavior
            }
            uc_reg_write(uc, reg, &v);
            return 1; // handled: skip the real (trapping) read
        }
        return 0;
    }

    int init_unicorn(FindDec &findDec) {

        shellcode &code = *findDec.get_shellcode();

        uc_err err = uc_open(UC_ARCH_ARM64, UC_MODE_ARM, &uc);
        if (err) {
            printf("Failed on uc_open() with error returned: %u (%s)\n", err,
                   uc_strerror(err));
            return -1;
        }

        err = uc_ctl_set_cpu_model(uc, UC_CPU_ARM64_MAX);
        if (err != UC_ERR_OK) {
            printf("set cpu model warn %s\n", uc_strerror(err));
        }

        // 鏄犲皠涓€娈靛熀纭€鍐呭瓨锛堜唬鐮佸尯锛?
        err = uc_mem_map(uc, code.start_addr(), code.size(), UC_PROT_ALL);
        if (err) {
            uc_close(uc);
            printf("Failed on uc_mem_map() with error returned: %u (%s)\n", err,
                   uc_strerror(err));
            return -1;
        }
        err = uc_mem_write(uc, code.start_addr(), code.data(), code.size());
        if (err) {
            uc_close(uc);
            printf("Failed on uc_mem_write() with error returned: %u (%s)\n", err,
                   uc_strerror(err));
            return -1;
        }

        // 鏄犲皠鏍堝唴瀛橈紙鍙鍐欙紝涓嶅彲鎵ц锛?
        err = uc_mem_map(uc, stack_base - stack_size, stack_size, UC_PROT_READ | UC_PROT_WRITE);
        if (err) {
            uc_close(uc);
            printf("Failed on uc_mem_map() with error returned: %u (%s)\n", err,
                   uc_strerror(err));
            return -1;
        }

        // X1
        err = uc_mem_map(uc, sp_base, 4096, UC_PROT_READ | UC_PROT_WRITE);
        if (err) {
            uc_close(uc);
            printf("Failed on uc_mem_map() with error returned: %u (%s)\n", err,
                   uc_strerror(err));
            return -1;
        }

        // 娉ㄥ唽鏈槧灏勫唴瀛?hook
        uc_hook hh;
        err = uc_hook_add(uc, &hh,
                          UC_HOOK_MEM_READ_UNMAPPED |
                          UC_HOOK_MEM_WRITE_UNMAPPED |
                          UC_HOOK_MEM_FETCH_UNMAPPED,
                          (void *) hook_mem_invalid, nullptr, 1, 0);
        if (err) {
            uc_close(uc);
            printf("Failed on uc_hook_add() with error returned: %u (%s)\n", err,
                   uc_strerror(err));
            return -1;
        }

        uc_hook hh3;
        err = uc_hook_add(uc, &hh3, UC_HOOK_INSN, (void *) hook_mrs, nullptr, 1, 0,
                          UC_ARM64_INS_MRS);
        if (err) {
            printf("[v2] add mrs hook fail %s\n", uc_strerror(err));
            uc_close(uc); uc = nullptr; return -1;
        }

        if (!init_shellcode_offset(findDec)) {
            printf("failed init shellcode offset\n");
            return -1;
        }

        return 0;
    }

    void close_unicorn() {
        uc_close(uc);
    }

    static std::function<void(uc_engine *uc, uint64_t address, uint32_t size,
                              void *user_data)> params_hook;

    static void get_params_hook(uc_engine *uc, uint64_t address, uint32_t size,
                                void *user_data) {
        params_hook(uc, address, size, user_data);
    }


    int execute_all_params(uint64_t X0, uint64_t X1, uint64_t el0, std::vector<VarParam> &varParams, std::vector<param> &memParams, uint64_t lo, uint64_t hi) {

           for (const auto &addr: mmap) {
            uc_mem_unmap(uc, addr, 0x1000);
        }
        mmap.clear();

        uint64_t stack_top = stack_base;

        uc_reg_write(uc, UC_ARM64_REG_SP, &stack_top);
        uc_reg_write(uc, UC_ARM64_REG_PC, &v87_compute_start);
        uc_reg_write(uc, UC_ARM64_REG_X0, &X0);
        uc_reg_write(uc, UC_ARM64_REG_TPIDR_EL0, &el0);

        uc_mem_write(uc, sp_base + 0x200, &X1, sizeof(X1));
        uc_reg_write(uc, UC_ARM64_REG_X1, &sp_base);

        uc_err err;

        uc_hook hh;
        err = uc_hook_add(uc, &hh, UC_HOOK_CODE, (void *) get_params_hook, NULL, 1, 0);
        if (err) {
            uc_close(uc);
            printf("Failed on uc_hook_add() with error returned: %u (%s)\n", err,
                   uc_strerror(err));
            return -1;
        }

        params_hook = [&](uc_engine *uc, uint64_t address, uint32_t size,
                          void *user_data) {
            for (auto &p: varParams) {
                if (p.addr == address) {
                    uc_reg_read(uc, convert_reg(p.reg), &p.value);
                }
            }

            if (address == shellcode_end - 36) {
                uc_emu_stop(uc);
            }

   uint32_t insn;

            if (uc_mem_read(uc, address, &insn, 4) != UC_ERR_OK)
                return;

            const uint32_t PACGA_MASK = 0xFFE0FC00;
            const uint32_t PACGA_OPCODE = 0x9AC03000;

            if ((insn & PACGA_MASK) != PACGA_OPCODE)
                return;

            uint32_t rd = insn & 0x1f;
            uint32_t rn = (insn >> 5) & 0x1f;
            uint32_t rm = (insn >> 16) & 0x1f;

            uint64_t vd, vn, vm;

            uc_reg_read(uc, UC_ARM64_REG_X0 + rn, &vn);
            uc_reg_read(uc, UC_ARM64_REG_X0 + rm, &vm);

            vd = pauth_computepac(vn, vm, {lo, hi});

            uc_reg_write(uc, UC_ARM64_REG_X0 + rd, &vd);


            printf("PACGA\n");
            printf(" Rd = X%d = 0x%llx\n", rd, (unsigned long long) vd);
            printf(" Rn = X%d = 0x%llx\n", rn, (unsigned long long) vn);
            printf(" Rm = X%d = 0x%llx\n", rm, (unsigned long long) vm);

            uint64_t pc = address + 4;
            uc_reg_write(uc, UC_ARM64_REG_PC, &pc);
        };


        std::cout << "[params]unicorn start: from-0x" << dfm_dec_format::Format("{:x}", v87_compute_start)
                  << " to-0x" << dfm_dec_format::Format("{:x}", v87_compute_start)
                  << std::endl;

        any = true;
        err = uc_emu_start(uc, v87_compute_start, all_params_exec_end, 1000 * 1000 * 10, 0);
        if (err) {
            uint64_t pc;
            uint64_t lr;
            uc_reg_read(uc, UC_ARM64_REG_PC, &pc);
            uc_reg_read(uc, UC_ARM64_REG_LR, &lr);
            printf("PC = 0x%lx\n", pc);
            printf("LR = 0x%lx\n", lr);
            printf("[params-for_SP]Failed on uc_emu_start() with error returned: %u (%s)\n", err, uc_strerror(err));
            //return -1;
        }

        uint64_t sp;
        uc_reg_read(uc, UC_ARM64_REG_SP, &sp);
        for (auto &p: memParams) {
            // Capture the value produced by the emulated prologue. For a
            // chained memory expression this is the root pointer stored on
            // the stack, not the final leaf value. The caller resolves the
            // chain in target memory after this function returns.
            p.value = 0;
            const size_t capture_size = p.offset.empty() ? p.size : sizeof(p.value);
            const uc_err read_err = uc_mem_read(uc, sp + p.disp, &p.value, capture_size);
            if (read_err != UC_ERR_OK) {
                any = false;
                uc_hook_del(uc, hh);
                printf("[params] read stack param failed name=%s sp=0x%llx disp=%d size=%zu err=%u (%s)\n",
                       p.name.c_str(),
                       static_cast<unsigned long long>(sp),
                       p.disp,
                       capture_size,
                       read_err,
                       uc_strerror(read_err));
                return -1;
            }
        }

        stack_top = stack_base;
        uc_reg_write(uc, UC_ARM64_REG_SP, &stack_top);

        uc_reg_write(uc, UC_ARM64_REG_PC, &v87_compute_start);
        uc_reg_write(uc, UC_ARM64_REG_X0, &X0);
        uc_reg_write(uc, UC_ARM64_REG_TPIDR_EL0, &el0);

        uc_mem_write(uc, sp_base + 0x200, &X1, sizeof(X1));
        uc_reg_write(uc, UC_ARM64_REG_X1, &sp_base);

        std::cout << "[params]unicorn start: from-0x" << dfm_dec_format::Format("{:x}", v87_compute_start)
                  << " to-0x" << dfm_dec_format::Format("{:x}", all_params_exec_end)
                  << std::endl;

        err = uc_emu_start(uc, v87_compute_start, all_params_exec_end, 0, 0);
        if (err) {
            any = false;
            uc_hook_del(uc, hh);
            uint64_t pc;
            uint64_t lr;
            uc_reg_read(uc, UC_ARM64_REG_PC, &pc);
            uc_reg_read(uc, UC_ARM64_REG_LR, &lr);
            printf("PC = 0x%lx\n", pc);
            printf("LR = 0x%lx\n", lr);
            printf("[param-for_X?]Failed on uc_emu_start() with error returned: %u (%s)\n", err, uc_strerror(err));
            return -1;
        }


        any = false;
        uc_hook_del(uc, hh);

        return 0;
    }

    int execute_hash_binary_search(uint64_t X0, uint64_t X1, uint32_t count, uint64_t &x8, uint64_t el0) {
        if (last_count != count) {
            last_count = count;
            for (const auto &addr: mmap) {
                uc_mem_unmap(uc, addr, 0x1000);
            }
            mmap.clear();
        }

        uint64_t stack_top = stack_base;    // 鍒濆 SP = 鏍堝簳锛堥珮鍦板潃锛?

        // 璁剧疆 SP 瀵勫瓨鍣?
        uc_reg_write(uc, UC_ARM64_REG_SP, &stack_top);

        // 璁剧疆 PC
        uc_reg_write(uc, UC_ARM64_REG_PC, &hash_binary_search_start);
        uc_reg_write(uc, UC_ARM64_REG_X0, &X0);
        uc_reg_write(uc, UC_ARM64_REG_TPIDR_EL0, &el0);
        uc_mem_write(uc, sp_base + 0x200, &X1, sizeof(X1));
        uc_reg_write(uc, UC_ARM64_REG_X1, &sp_base);

        uc_err err = uc_emu_start(uc, hash_binary_search_start, hash_binary_search_end, 1000 * 100, 0);
        if (err) {
            uint64_t pc;
            uint64_t lr;
            uc_reg_read(uc, UC_ARM64_REG_PC, &pc);
            uc_reg_read(uc, UC_ARM64_REG_LR, &lr);
            printf("PC = 0x%lx\n", pc);
            printf("LR = 0x%lx\n", lr);
            printf("Failed on uc_emu_start() with error returned: %u (%s)\n", err, uc_strerror(err));
            return err;
        }

        uint64_t pc;
        uc_reg_read(uc, UC_ARM64_REG_PC, &pc);
        if (pc != hash_binary_search_end) {
            printf("time out!\n");
            return -2;
        }

        x8 = 0;
        uc_reg_read(uc, hash_binary_search_reg, &x8);

        std::cout << "X8 = 0x" << dfm_dec_format::Format("{:x}", x8) << std::endl;

        return 0;
    }

    uint64_t execute_v87_compute(uint64_t X0) {
           for (const auto &addr: mmap) {
            uc_mem_unmap(uc, addr, 0x1000);
        }
        mmap.clear();

        uint64_t stack_top = stack_base;

        uc_reg_write(uc, UC_ARM64_REG_SP, &stack_top);

        // 璁剧疆 PC
        uc_reg_write(uc, UC_ARM64_REG_PC, &v87_compute_start);
        uc_reg_write(uc, UC_ARM64_REG_X0, &X0);

        std::cout << "[v87]unicorn start: from-0x" << dfm_dec_format::Format("{:x}", v87_compute_start)
                  << " to-0x" << dfm_dec_format::Format("{:x}", v87_compute_end)
                  << std::endl;
        printf("x0: %llx\n", X0);
        // 寮€濮嬫墽琛岋紙鎸囧畾 start 鍜?end锛?
        uc_err err = uc_emu_start(uc, v87_compute_start, v87_compute_end, 1000 * 1000 * 2, 0);
        if (err) {
            printf("[v87]Failed on uc_emu_start() with error returned: %u (%s)\n", err, uc_strerror(err));
            uint64_t pc;
            uint64_t lr;
            uc_reg_read(uc, UC_ARM64_REG_PC, &pc);
            uc_reg_read(uc, UC_ARM64_REG_LR, &lr);
            printf("PC = 0x%lx\n", pc);
            printf("LR = 0x%lx\n", lr);
            printf("Failed on uc_emu_start() with error returned: %u (%s)\n", err, uc_strerror(err));
            return 0;
        }
        // 璇诲彇 X8
        uint64_t x8 = 0;
        uc_reg_read(uc, v87_compute_reg, &x8);

        std::cout << "X8 = 0x" << dfm_dec_format::Format("{:x}", x8) << std::endl;
        return x8;
    }


    static void handle_ioctl(uc_engine *uc) {
        uint64_t fd;
        uint64_t request;
        uint64_t argp;

        uc_reg_read(uc, UC_ARM64_REG_X0, &fd);
        uc_reg_read(uc, UC_ARM64_REG_X1, &request);
        uc_reg_read(uc, UC_ARM64_REG_X2, &argp);

        printf(
                "ioctl(fd=%llu, req=0x%llx, arg=0x%llx)\n",
                (unsigned long long) fd,
                (unsigned long long) request,
                (unsigned long long) argp
        );
        char path[96]{};
        //snprintf(path, sizeof(path), "/proc/%d/fd/%u", targetPid, fd);
        int localFd = open(path, O_RDWR | O_CLOEXEC);
        if (localFd < 0) {
            printf("fd open failed\n");
            return;
        }

        uint64_t o[4];
        ioctl(fd, request, o);
        std::cout << "ioctl: " << o[0] << std::endl;

        uc_emu_stop(uc);
    }

    static void hook_intr(
            uc_engine *uc,
            uint32_t intno,
            void *user_data) {
        uint64_t nr;

        uc_reg_read(
                uc,
                UC_ARM64_REG_X8,
                &nr
        );

        if (nr == __NR_ioctl) {
            handle_ioctl(uc);
        }
    }

}
