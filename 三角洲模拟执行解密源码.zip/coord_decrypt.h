#pragma once
开源频道:@enennba
#include <cstddef>
#include <cstdint>
#include <string>

namespace CoordDecrypt
{
struct Coordinate
{
	float x = 0.0f;
	float y = 0.0f;
	float z = 0.0f;
};

struct ShellcodeDumpResult
{
	bool saved = false;
	bool complete = false;
	uint64_t base = 0;
	uint64_t entry = 0;
	size_t size = 0;
	size_t pagesRead = 0;
	size_t pagesFailed = 0;
	std::string directory;
	std::string textPath;
	std::string binaryPath;
	std::string message;
};

void Tick(bool enabled, uint64_t libUE4);
bool TryRead(uint64_t component, Coordinate &out);
ShellcodeDumpResult DumpShellcode(uint64_t libUE4);
void Reset();
}
开源频道:@enennba